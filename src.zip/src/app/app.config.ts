

export const Registro ={
  nombre:'',
  apellido: '',
  edad:'',
  cedula:'',
  genero: '',
  ciudad:''

};
