import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistroEdadPage } from './registro-edad';

@NgModule({
  declarations: [
    RegistroEdadPage,
  ],
  imports: [
    IonicPageModule.forChild(RegistroEdadPage),
  ],
})
export class RegistroEdadPageModule {}
