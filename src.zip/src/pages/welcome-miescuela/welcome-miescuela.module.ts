import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { WelcomeMiescuelaPage } from './welcome-miescuela';


@NgModule({
  declarations: [
    WelcomeMiescuelaPage,
  ],
  imports: [
    IonicPageModule.forChild(WelcomeMiescuelaPage),
  ],
})
export class WelcomeMiescuelaPageModule {}
