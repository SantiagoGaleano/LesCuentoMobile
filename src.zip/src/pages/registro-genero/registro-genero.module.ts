import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistroGeneroPage } from './registro-genero';

@NgModule({
  declarations: [
    RegistroGeneroPage,
  ],
  imports: [
    IonicPageModule.forChild(RegistroGeneroPage),
  ],
})
export class RegistroGeneroPageModule {}
